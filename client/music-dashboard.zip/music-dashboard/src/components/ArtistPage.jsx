import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./artistpage.css";
import lastfmIcon from "./last_ico.ico";
import db from "../data/dummyDB";

function useQuery() {
  const { search } = useLocation();
  return new URLSearchParams(search);
}

function ArtistPage() {
  const query = useQuery();
  const artistName = query.get("artist") || "Unknown Artist";

  const navigate = useNavigate(); // ✅ Add it here

  const artistAlbums = db.albums.filter(
    (album) => album.artist === artistName
  );

  const [hoverCover, setHoverCover] = useState(null);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const move = (e) => setMouse({ x: e.clientX, y: e.clientY });
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, []);

  return (
    <div className="main-content artist-list-section">
      <div className="artist-container">
        <div className="artist-header">
          <div className="artist-name-block">
            <h2>{artistName}</h2>
            <a
              href={`https://www.last.fm/music/${encodeURIComponent(
                artistName
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              title="View on Last.fm"
            >
              <img src={lastfmIcon} alt="Last.fm" className="lastfm-icon" />
            </a>
          </div>
        </div>

        <div className="albums-header">
          <div>Album</div>
          <div>Year</div>
          <div>Songs</div>
          <div>Size</div>
          <div>Plays</div>
        </div>

        <div className="album-list">
          {artistAlbums.map((album, index) => (
            <div
              key={index}
              className="album-row"
              onClick={() => navigate(`/album?album=${encodeURIComponent(album.title)}`)}
              onMouseMove={() => setHoverCover(album.img)}
              onMouseLeave={() => setHoverCover(null)}
            >
              <div>{album.title}</div>
              <div>{album.year}</div>
              <div>{album.tracks?.length ?? "—"}</div>
              <div>{album.size}</div>
              <div>{album.plays?.toLocaleString?.() ?? "—"}</div>
            </div>
          ))}
        </div>
      </div>

      {hoverCover && (
        <div
          className="floating-preview"
          style={{
            top: `${mouse.y + 20}px`,
            left: `${mouse.x + 20}px`,
            display: "block",
          }}
        >
          <img src={hoverCover} alt="Preview" />
        </div>
      )}
    </div>
  );
}

export default ArtistPage;
