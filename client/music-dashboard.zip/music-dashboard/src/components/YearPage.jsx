import { useLocation, useNavigate } from "react-router-dom";
import "./albumgrid.css";
import { FaPlay, FaRandom } from "react-icons/fa";
import db from "../data/dummyDB";

function useQuery() {
  const { search } = useLocation();
  return new URLSearchParams(search);
}

function YearPage() {
  const query = useQuery();
  const navigate = useNavigate();
  const year = query.get("year");

  const filteredAlbums = db.albums.filter(album => String(album.year) === year);

  const parseSizeToMB = (sizeStr) => {
    const match = sizeStr.match(/^([\d.]+)(MB|GB)$/i);
    if (!match) return 0;
    const value = parseFloat(match[1]);
    const unit = match[2].toUpperCase();
    return unit === "GB" ? value * 1024 : value;
  };

  const totalSizeMB = filteredAlbums.reduce(
    (sum, album) => sum + parseSizeToMB(album.size || "0MB"),
    0
  );

  const readableSize =
    totalSizeMB >= 1024
      ? (totalSizeMB / 1024).toFixed(1) + " GB"
      : Math.round(totalSizeMB) + " MB";

  const goToAlbum = (title) => {
    navigate(`/album?album=${encodeURIComponent(title)}`);
  };

  const goToArtist = (e, artist) => {
    e.stopPropagation();
    navigate(`/artist?artist=${encodeURIComponent(artist)}`);
  };

return (
  <div className="main-content album-grid" id="albumContainer">
    {/* YEAR INFO TILE */}
    <div className="card" onClick={(e) => e.stopPropagation()}>
      <div className="album-image-wrapper">
        <img src="/img/year_tile_cover.jpg" alt={`Albums of ${year}`} />
      </div>
      <div className="card-info">
        <div>
          <div className="card-title">{year}</div>
          <div className="card-meta">{filteredAlbums.length} albums released</div>
          <div className="card-meta">{readableSize} total</div>
        </div>
        <div className="card-buttons">
          <button className="card-icon-button" onClick={(e) => e.stopPropagation()}>
            <FaPlay /> Play
          </button>
          <button className="card-icon-button" onClick={(e) => e.stopPropagation()}>
            <FaRandom /> Shuffle
          </button>
        </div>
      </div>
    </div>

    {/* ALBUM CARDS */}
    {filteredAlbums.map((album, index) => (
      <div
        key={index}
        className="card"
        onClick={() => goToAlbum(album.title)}
      >
        <div className="album-image-wrapper">
          <img src={album.img} alt={`Cover for ${album.title}`} />
        </div>

        <div className="card-info">
          <div>
            <div className="card-title">{album.title}</div>
            <div
              className="card-artist clickable"
              onClick={(e) => goToArtist(e, album.artist)}
            >
              {album.artist}
            </div>
            <div className="card-meta">Released: {album.year}</div>
          </div>

          <div className="card-buttons">
            <button
              className="card-icon-button"
              onClick={(e) => e.stopPropagation()}
            >
              <FaPlay /> Play
            </button>
            <button
              className="card-icon-button"
              onClick={(e) => e.stopPropagation()}
            >
              <FaRandom /> Shuffle
            </button>
          </div>
        </div>
      </div>
    ))}

    {filteredAlbums.length === 0 && (
      <p style={{ color: "gray", padding: "0 24px" }}>
        No albums found for {year}.
      </p>
    )}
  </div>
);

}

export default YearPage;
