import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./sidebar.css";

function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  // Collapse logic
  useEffect(() => {
    const handleResize = () => {
      const isNarrow = window.innerWidth < 768;
      setCollapsed(isNarrow);
      localStorage.setItem("sidebarCollapsed", isNarrow);
    };

    const stored = localStorage.getItem("sidebarCollapsed") === "true";
    if (window.innerWidth >= 768) setCollapsed(stored);
    else setCollapsed(true);

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    localStorage.setItem("sidebarCollapsed", collapsed);
  }, [collapsed]);

  // Handle sort selection
  const handleSort = (sortType) => {
    const searchParams = new URLSearchParams({ sort: sortType });
    navigate(`/?${searchParams.toString()}`);
  };

  const handleShowAll = () => {
    if (location.pathname === "/") {
      // Already on AlbumGrid, just refresh
      navigate("/", { replace: true });
    } else {
      navigate("/");
    }
  };

  return (
    <div className={`sidebar ${collapsed ? "collapsed" : ""}`}>
      <div className="sidebar-header">
        <h1 id="logo">Godspeed</h1>
        <div className="navi-block">
          <div className="nav-controls">
            <button title="Back" onClick={() => window.history.back()}>
              ←
            </button>
            <button title="Forward" onClick={() => window.history.forward()}>
              →
            </button>
          </div>

          <button
            id="toggleSidebar"
            onClick={() => setCollapsed(!collapsed)}
            title="Toggle Sidebar"
          >
            ≡
          </button>
          </div>
        </div>
      {!collapsed && (
        <>
          <input type="text" placeholder="Search..." />
          <div className="sort-controls">
            <button id="showAllBtn" onClick={handleShowAll}>
              All
            </button>
            <div className="sort-dropdown-wrapper">
              <button id="sortBtn">Sort By ▾</button>
              <div className="dropdown-menu" id="sortMenu">
                <button onClick={() => handleSort("az")}>A–Z</button>
                <button onClick={() => handleSort("za")}>Z–A</button>
                <button onClick={() => handleSort("random")}>Random</button>
              </div>
            </div>
          </div>

          <div className="category-block">
            <div className="category">Genres</div>
            <div className="category" onClick={() => navigate("/artists")}>
              Artists
            </div>
            <div className="category">Playlists</div>
            <div className="category">Favorites</div>
          </div>
        </>
      )}
    </div>
  );
}

export default Sidebar;
