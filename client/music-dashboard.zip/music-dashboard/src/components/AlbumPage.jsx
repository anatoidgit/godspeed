import { useState, useRef, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { createPortal } from "react-dom";
import "./albumpage.css";
import lastfmIcon from "./last_ico.ico";
import {
  FaPlay,
  FaRandom,
  FaStepForward,
  FaClock,
  FaEllipsisV,
  FaInfoCircle,
  FaTags,
} from "react-icons/fa";
import { useAudio } from "../context/AudioProvider";

function useQuery() {
  const { search } = useLocation();
  return new URLSearchParams(search);
}

function TrackDropdown({ track }) {
  const [open, setOpen] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [showLabel, setShowLabel] = useState(false);
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const buttonRef = useRef(null);

  useEffect(() => {
    if (open && buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      setPosition({
        top: rect.bottom + window.scrollY,
        left: rect.left + window.scrollX,
      });
    }
  }, [open]);

  return (
    <>
      <button
        ref={buttonRef}
        className="track-dropdown-button"
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
      >
        <FaEllipsisV />
      </button>

      {open &&
        createPortal(
          <div
            className={`track-dropdown-menu ${showLabel ? "expanded" : ""}`}
            style={{
              position: "absolute",
              top: `${position.top}px`,
              left: `${position.left}px`,
            }}
            onMouseEnter={() => setOpen(true)}
            onMouseLeave={() => {
              setOpen(false);
              setShowInfo(false);
              setShowLabel(false);
            }}
          >
            <button
              className="track-dropdown-icon"
              title="Play Next"
              onClick={(e) => {
                e.stopPropagation();
                console.log("Track queued to play next:", track.title);
              }}
            >
              <FaStepForward />
            </button>
            <button
              className="track-dropdown-icon"
              title="Play Later"
              onClick={(e) => {
                e.stopPropagation();
                console.log("Track added to play later:", track.title);
              }}
            >
              <FaClock />
            </button>

            <div
              className="track-dropdown-icon info-wrapper"
              onMouseEnter={() => setShowInfo(true)}
              onMouseLeave={() => setShowInfo(false)}
              title="Info"
            >
              <FaInfoCircle />
              {showInfo && (
                <div className="track-info-tooltip">
                  <table>
                    <tbody>
                      <tr>
                        <td>Duration:</td>
                        <td>{track.duration}s</td>
                      </tr>
                      <tr>
                        <td>Size:</td>
                        <td>{Math.round((track.file_size || 0) / 1024 / 1024)} MB</td>
                      </tr>
                      <tr>
                        <td>Codec:</td>
                        <td>{track.codec}</td>
                      </tr>
                      <tr>
                        <td>Bitrate:</td>
                        <td>{track.bitrate ? Math.round(track.bitrate / 1000) + " kbps" : "-"}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div
              className="label-wrapper"
              onMouseEnter={() => setShowLabel(true)}
              onMouseLeave={() => setShowLabel(false)}
              title="Add Label"
            >
              <div className="track-dropdown-icon">
                <FaTags />
              </div>

              {showLabel && (
                <div className="label-popup">
                  {track.labels?.length > 0 && (
                    <div className="label-tags-inline">
                      {track.labels.map((label, i) => (
                        <span key={i}>#{label}</span>
                      ))}
                    </div>
                  )}
                  <input
                    type="text"
                    placeholder="Add label"
                    className="track-label-input"
                    onClick={(e) => e.stopPropagation()}
                    onBlur={(e) => {
                      const newLabel = e.target.value.trim();
                      if (newLabel) {
                        track.labels = Array.from(
                          new Set([...(track.labels || []), newLabel])
                        );
                      }
                      e.target.value = "";
                    }}
                  />
                </div>
              )}
            </div>
          </div>,
          getDropdownRoot()
        )}
    </>
  );
}

function getDropdownRoot() {
  let container = document.getElementById("dropdown-root");
  if (!container) {
    container = document.createElement("div");
    container.id = "dropdown-root";
    document.body.appendChild(container);
  }
  return container;
}

function AlbumPage() {
  const query = useQuery();
  const albumTitle = query.get("album");

  const [album, setAlbum] = useState(null);
  const [tracks, setTracks] = useState([]);
  const [playingTrackIndex, setPlayingTrackIndex] = useState(null);

  const { playTrack } = useAudio();

  useEffect(() => {
    if (!albumTitle) return;

    fetch("http://localhost:4000/albums")
      .then(res => res.json())
      .then(albums => {
        const found = albums.find(a => a.title.toLowerCase() === albumTitle.toLowerCase());
        if (found) {
          // Initialize labels if they don't exist
          if (!found.labels) found.labels = [];
          setAlbum(found);
          fetch(`http://localhost:4000/tracks?album_id=${found.id}`)
            .then(res => res.json())
            .then(tracks => {
              // Initialize labels for each track if they don't exist
              tracks.forEach(track => {
                if (!track.labels) track.labels = [];
              });
              setTracks(tracks);
            });
        }
      });
  }, [albumTitle]);

  const togglePlay = (index) => {
    const track = tracks[index];
    if (!track) return;

    // If the same track is already playing, toggle play/pause
    if (playingTrackIndex === index) {
      // You'll need to expose a togglePlayPause function from your AudioProvider
      // or handle this logic in your audio context
      return;
    }

    // Prepare the track data for playback
    playTrack({
      id: track.id,
      title: track.title,
      artist: track.album_artist || album.album_artist || "Unknown Artist",
      album: album.title,
      duration: track.duration,
      audioSrc: `http://localhost:4000/track/${track.id}/play`, // Add this endpoint to your server
      albumCover: `http://localhost:4000/album/${album.id}/cover`,
      waveformImage: track.waveform_path || "/waveforms/default.webp",
      // Include additional metadata if needed
      codec: track.codec,
      bitrate: track.bitrate,
      fileSize: track.file_size,
    });

    setPlayingTrackIndex(index);
  };

  const handleAlbumLabelAdd = (e) => {
    const newLabels = e.target.value
      .split(",")
      .map((l) => l.trim())
      .filter(Boolean);
    if (newLabels.length > 0) {
      album.labels = Array.from(new Set([...(album.labels || []), ...newLabels]));
      e.target.value = "";
    }
  };

  if (!album) return <div className="main-content">Loading album...</div>;

  return (
    <div className="main-content album-list-section">
      <div className="album-container">
        <div className="album-header-block">
          <img
            className="album-cover"
            src={`http://localhost:4000/album/${album.id}/cover`}
            alt={album.title}
          />
          <div className="album-info-block">
            <h2>{album.title}</h2>
            <div className="album-meta-row">
              <p>
                {album.album_artist || "Unknown Artist"} • {album.year} • {tracks.length} tracks • {album.duration}
              </p>
              <a
                href={`https://www.last.fm/music/${encodeURIComponent(
                  album.album_artist || "Unknown Artist"
                )}/${encodeURIComponent(album.title)}`}
                target="_blank"
                rel="noopener noreferrer"
                title="View on Last.fm"
              >
                <img className="lastfm-icon" src={lastfmIcon} alt="Last.fm" />
              </a>
            </div>

            <div className="album-labels">
              <div className="label-tags">
                {album.labels?.map((label, i) => (
                  <span className="label-tag" key={i}>
                    #{label}
                  </span>
                ))}
              </div>
              <input
                type="text"
                className="label-input"
                placeholder="Add labels"
                onBlur={handleAlbumLabelAdd}
              />
            </div>

            <div className="album-actions">
              <button>
                <FaPlay /> Play
              </button>
              <button>
                <FaRandom /> Shuffle
              </button>
              <button>
                <FaStepForward /> Next
              </button>
              <button>
                <FaClock /> Later
              </button>
            </div>
          </div>
        </div>

        <div className="tracks-table">
          <div className="tracks-header">
            <div>No.</div>
            <div>Title</div>
            <div className="meta-group">
              <div>Duration</div>
              <div>Size</div>
              <div>Codec</div>
              <div>Bitrate</div>
            </div>
            <div></div>
          </div>
          {tracks.map((track, idx) => (
            <div
              className={`tracks-row ${playingTrackIndex === idx ? "playing" : ""}`}
              key={track.id}
              onClick={() => togglePlay(idx)}
            >
              <div>{idx + 1}</div>
              <div className="track-title-cell">{track.title}</div>
              <div className="meta-group">
                <div>{track.duration}s</div>
                <div>{Math.round((track.file_size || 0) / 1024 / 1024)} MB</div>
                <div>{track.codec}</div>
                <div>{track.bitrate ? Math.round(track.bitrate / 1000) + " kbps" : "-"}</div>
              </div>
              <TrackDropdown track={track} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default AlbumPage;