// PlayerFooter.jsx
import React, { useRef } from "react";
import { useAudio } from "../context/AudioProvider";
import {
  FaPlay,
  FaPause,
  FaStepForward,
  FaStepBackward,
  FaVolumeUp,
  FaHeart,
  FaTags,
  FaInfoCircle,
} from "react-icons/fa";
import "./PlayerFooter.css";
import waveformImg from "./wf.png"; // path must be correct based on file location


const formatTime = (seconds) => {
  if (isNaN(seconds)) return "00:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60).toString().padStart(2, "0");
  return `${mins}:${secs}`;
};

function PlayerFooter() {
  const {
    currentTrack,
    isPlaying,
    togglePlayPause,
    progress,
    duration,
    seekTo,
    volume,
    setVolume,
  } = useAudio();

  const waveformRef = useRef(null);

  const handleSeek = (e) => {
    const rect = waveformRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percent = clickX / rect.width;
    seekTo(percent);
  };

  if (!currentTrack) {
    return (
      <div className="player-footer empty">
        <p>No track playing</p>
      </div>
    );
  }

  return (
    <div className="player-footer">
    
      {/* Left Section: Track Info */}
      <div className="player-section info-block">
        <img
          src={currentTrack.albumCover}
          alt="Cover"
          className="cover-art"
        />
        <div className="track-meta">
          <h4 className="track-title">{currentTrack.name}</h4>
          <p className="track-details">
            {currentTrack.artist} • {currentTrack.album} • {currentTrack.year}
          </p>
        </div>
      </div>

      {/* Center Section: Playback Controls and Waveform */}
      <div className="player-section control-block">

        {/* Playback Controls */}
        <div className="controls">
          <button onClick={() => seekTo(0)} title="Previous">
            <FaStepBackward />
          </button>
          <button onClick={togglePlayPause} title="Play/Pause">
            {isPlaying ? <FaPause /> : <FaPlay />}
          </button>
          <button title="Next">
            <FaStepForward />
          </button>
        </div>

        <div className="waveform-row">
          <span className="wave-time">{formatTime(progress * duration)}</span>
       {/* Waveform and Progress */}
        <div
          className="waveform-wrapper"
          onClick={handleSeek}
          ref={waveformRef}
        >
          {/* Static full waveform background */}
          <img
            src={waveformImg}
            alt="Waveform Background"
            className="waveform-static"
          />

          {/* Mask overlay to hide the right side (unreached progress) */}
          <div
            className="waveform-mask"
            style={{ width: `${(1 - progress) * 100}%` }}
          />

          {/* Foreground progress bar with knob */}
          <div className="progress-bar-foreground">
            <div
              className="progress-knob"
              style={{ left: `${progress * 100}%` }}
            />
          </div>
        </div>

          <span className="wave-time">{formatTime(duration)}</span>
        </div>

      </div>
      {/* Right Section: Track Specs and Actions */}
      <div className="player-section quality-block">

        {/* Track Quality Info */}
        <div className="audio-specs">
          <span>{currentTrack.bitrate}</span>
          <span>{currentTrack.quality || "FLAC"}</span>
          <span>{currentTrack.size}</span>
        </div>

        {/* Volume Control */}
        <div className="volume-slider">
          <FaVolumeUp />
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={volume}
            onChange={(e) => setVolume(parseFloat(e.target.value))}
          />
        </div>

        {/* Action Buttons */}
        <div className="footer-actions">
          <button title="Label">
            <FaTags />
          </button>
          <button title="Metadata">
            <FaInfoCircle />
          </button>
          <button title="Favorite">
            <FaHeart />
          </button>
        </div>
      </div>
    </div>
  );

}

export default PlayerFooter;
