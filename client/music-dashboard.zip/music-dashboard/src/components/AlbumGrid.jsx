import { useNavigate, useLocation } from "react-router-dom";
import { useEffect, useState } from 'react';
import "./albumgrid.css";
import { FaPlay, FaRandom } from "react-icons/fa";

function AlbumGrid() {
  const navigate = useNavigate();
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const sortType = params.get("sort") || "az";

  const [albums, setAlbums] = useState([]);

  useEffect(() => {
    fetch('http://localhost:4000/albums')
      .then(res => res.json())
      .then(data => {
        setAlbums(data);
      })
      .catch(err => console.error('❌ Failed to fetch albums:', err));
  }, []);

  const sortedAlbums = [...albums].sort((a, b) => {
    const aTitle = a.title.toLowerCase();
    const bTitle = b.title.toLowerCase();
    if (sortType === "az") return aTitle.localeCompare(bTitle);
    if (sortType === "za") return bTitle.localeCompare(aTitle);
    if (sortType === "random") return Math.random() - 0.5;
    return 0;
  });

  const goToAlbum = (title) => {
    navigate(`/album?album=${encodeURIComponent(title)}`);
  };

  const goToArtist = (e, artist) => {
    e.stopPropagation();
    navigate(`/artist?artist=${encodeURIComponent(artist)}`);
  };

  const goToYear = (e, year) => {
    e.stopPropagation();
    navigate(`/year?year=${encodeURIComponent(year)}`);
  };

  return (
    <div className="album-grid" id="albumContainer">
      {sortedAlbums.map((album) => (
        <div
          key={album.id}
          className="card"
          onClick={() => goToAlbum(album.title)}
          data-title={album.title}
          data-artist={album.album_artist}
        >
          <div className="album-image-wrapper">
            <img
              src={`http://localhost:4000/album/${album.id}/cover`}
              alt={`Cover for ${album.title}`}
              onError={(e) => e.target.style.display = 'none'} // fallback
            />
          </div>
          <div className="card-info">
            <div>
              <div className="card-title">{album.title}</div>
              <div
                className="card-artist clickable"
                onClick={(e) => goToArtist(e, album.album_artist || 'Unknown Artist')}
              >
                {album.album_artist || 'Unknown Artist'}
              </div>
              <div
                className="card-meta clickable"
                onClick={(e) => goToYear(e, album.year)}
              >
                Year: {album.year || '—'}
              </div>
            </div>
            <div className="card-buttons">
              <button onClick={(e) => e.stopPropagation()}>
                <FaPlay /> Play
              </button>
              <button onClick={(e) => e.stopPropagation()}>
                <FaRandom /> Shuffle
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default AlbumGrid;
