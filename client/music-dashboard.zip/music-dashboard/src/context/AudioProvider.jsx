import React, { createContext, useContext, useEffect, useRef, useState } from "react";

const AudioContext = createContext();

export const useAudio = () => useContext(AudioContext);

const AudioProvider = ({ children }) => {
  const audioRef = useRef(new Audio());
  const [currentTrack, setCurrentTrack] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1); // 1 = 100%

  // Load new track
  const playTrack = (track) => {
    if (!track?.url) return;
    const audio = audioRef.current;
    audio.src = track.url;
    audio.load();
    audio.play();
    setCurrentTrack(track);
    setIsPlaying(true);
  };

  const togglePlayPause = () => {
    const audio = audioRef.current;
    if (!audio.src) return;
    if (audio.paused) {
      audio.play();
      setIsPlaying(true);
    } else {
      audio.pause();
      setIsPlaying(false);
    }
  };

  const seekTo = (percent) => {
    const audio = audioRef.current;
    if (!audio.duration) return;
    audio.currentTime = percent * audio.duration;
  };

  const setVolumeLevel = (value) => {
    const audio = audioRef.current;
    audio.volume = value;
    setVolume(value);
  };

  // Update progress on timeupdate
  useEffect(() => {
    const audio = audioRef.current;

    const handleTimeUpdate = () => {
      setProgress(audio.currentTime / audio.duration || 0);
    };

    const handleLoadedMetadata = () => {
      setDuration(audio.duration);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setProgress(0);
    };

    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("loadedmetadata", handleLoadedMetadata);
    audio.addEventListener("ended", handleEnded);

    return () => {
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
      audio.removeEventListener("ended", handleEnded);
    };
  }, []);

  return (
    <AudioContext.Provider
      value={{
        currentTrack,
        isPlaying,
        playTrack,
        togglePlayPause,
        seekTo,
        progress,
        duration,
        volume,
        setVolume: setVolumeLevel,
      }}
    >
      {children}
    </AudioContext.Provider>
  );
};

export default AudioProvider;
