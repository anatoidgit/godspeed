import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import AlbumGrid from "./components/AlbumGrid";
import ArtistsList from "./components/ArtistsList";
import ArtistPage from "./components/ArtistPage";
import AlbumPage from "./components/AlbumPage";
import YearPage from "./components/YearPage";
import PlayerFooter from "./components/PlayerFooter";
import AudioProvider from "./context/AudioProvider";
import "./App.css";

function App() {
  return (
    <AudioProvider>
      <Router>
        <div className="app-layout">
          <Sidebar />

          <div className="main-content">
            <Routes>
              <Route path="/" element={<AlbumGrid />} />
              <Route path="/artists" element={<ArtistsList />} />
              <Route path="/artist" element={<ArtistPage />} />
              <Route path="/album" element={<AlbumPage />} />
              <Route path="/year" element={<YearPage />} />
            </Routes>
          </div>

          {/* PlayerFooter will internally use the global audio context */}
          <PlayerFooter />
        </div>
      </Router>
    </AudioProvider>
  );
}

export default App;
